//============================================================================
// Name        : booos.cc
// Author      : Arliones Hoeller
// Version     :
// Copyright   : Santa Catarina Federal Institute of Technology - 2014
// Description : BOOOS Application
//============================================================================

#include <iostream>
#include <BOOOS.h>

using namespace std;
using namespace BOOOS;
BOOOS::BOOOS  _booos;


int main() {

	cout << "I'm a dummy app that does nothing..." << endl;

}
