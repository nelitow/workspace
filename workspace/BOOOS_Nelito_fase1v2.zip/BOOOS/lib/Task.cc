/*
 * Task.cc
 *
 *  Created on: Feb 27, 2014
 *      Author: arliones
 */

#include "Task.h"
#include <iostream>

namespace BOOOS {

volatile Task * Task::__running;
Task * Task::__main;
int Task::__tid_counter;

Task::Task(void (*entry_point)(void*), int nargs, void * arg) {
	getcontext(&this->_context);
	_stack = (char*)malloc(STACK_SIZE);
	if (_stack){
		this->_context.uc_stack.ss_sp = _stack;
		this->_context.uc_stack.ss_size = STACK_SIZE;
		this->_context.uc_stack.ss_flags = 0;
		this->_context.uc_link = 0;
		makecontext(&this->_context, (void(*)()) entry_point, nargs, arg);
		this->_tid = __tid_counter++;
		this->_state = READY;
		//std::cout << "\n" <<"eaiiiiiiiiiiiii" << __tid_counter << std::endl;
	}
}

Task::Task() {
	this->_stack = 0;
	getcontext(&_context);
	this->_tid = __tid_counter;
	__tid_counter = 2; //retirar
	_state = READY;
}

Task::~Task() {
	free(this->_stack);
}

void Task::init() {
	__tid_counter = 0;
	__main = new Task();
	__main->_state = RUNNING;
	__running = __main;

	//__ready;

	//_tid;
	//_context;
	//_state;
}

void Task::pass_to(Task * t, State s) {
	this->_state = s;
	swapcontext(&this->_context, &t->_context);
}

void Task::exit(int code) {
	swapcontext(&this->_context, &this->__main->_context);
}
} /* namespace BOOOS */
