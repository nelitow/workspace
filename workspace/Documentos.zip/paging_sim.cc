#include <iostream>
#include <sstream>
#include <math.h>
#include "MapFile.cc"
#include <string>

using namespace std;

int main(int argc, char* argv[]){
	char *pCh;
	unsigned int base = 0;
	unsigned int n = 0;

	unsigned int largura = 0;
	unsigned int tamanho = 0;
	string arquivo = "eai men";
	unsigned int endereco = 12;

	unsigned int frames = 0;
	unsigned int page = 0;
	unsigned int frame = 0;
	unsigned int offset = 0;
	unsigned int phys_address = 0;

	largura = strtoul (argv[1], &pCh, 10);
	tamanho = strtoul (argv[2], &pCh, 10);
	arquivo = argv[3];
	endereco = strtoul (argv[4], &pCh, 10);

	frames = tamanho/largura;


	MapFile page_table(argv[3]);
	frame = page_table.get_frame(2);
	
	n = (unsigned int) log(tamanho);
	page = endereco >> n;
	unsigned int mask = tamanho - 1;
	offset = endereco & mask;

	
	
	cout << "Quadros no sistema: " << frames << endl;
	cout << "Pagina requisitada: " << page << endl;
	cout << "Quadro requisitado: " << frame << endl;
	cout << "Deslocamento: " << offset;	
	cout << hex;
	cout << " (" << offset << ")" << endl;
	cout << "Endereco logico: 0x" << endereco << endl;
	cout << "Endereco fisico: " << phys_address << endl;
}
